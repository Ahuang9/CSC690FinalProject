//
//  ForecastCell.swift
//  WeatherApp
//
//  Created by Ashley Huang on 12/27/20.
//  Copyright © 2020 Ashley Huang. All rights reserved.
//

import UIKit

class ForecastCell: UITableViewCell {
    
    @IBOutlet weak var ForecastDate: UILabel!
    
    @IBOutlet weak var ForecastTemp: UILabel!
    
    func configCell(temp: Int, Date: String) {
        self.ForecastDate.text = Date
        self.ForecastTemp.text = "\(temp)"
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
