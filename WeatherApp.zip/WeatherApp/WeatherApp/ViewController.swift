//
//  ViewController.swift
//  WeatherApp
//
//  Created by Ashley Huang on 12/1/20.
//  Copyright © 2020 Ashley Huang. All rights reserved.
//

import UIKit
import CoreLocation // To get user's location
import Foundation
import Alamofire    // Library
import NVActivityIndicatorView  // Library
import SwiftyJSON   // Library

class ViewController: UIViewController, CLLocationManagerDelegate {
    
    @IBOutlet weak var locationLabel: UILabel!
    
    @IBOutlet weak var dayLabel: UILabel!
    
    @IBOutlet weak var temperatureLabel: UILabel!
    
    @IBOutlet weak var conditionLabel: UILabel!
    
    @IBOutlet weak var conditionImageView: UIImageView!
    
    @IBOutlet weak var backgroundView: UIView!
    
    let tintLayer = CAGradientLayer()
    
    let apiKey = "fb27e6d4029948f1871f92eba845a51d" // Recieved an api key from openweathermap.org
    var lat = 37.7749   // latitude for San Francisco
    var lon = 122.4194  // longitude for San Francisco
    var activityIndicator: NVActivityIndicatorView!
    let locationManager = CLLocationManager()   // Handles getting user's location
    
    // Background for day time
    func setDayTintBackground(){
        let topColor = UIColor(red: 95.0/255.0, green: 165.0/255.0, blue: 1.0, alpha: 1.0).cgColor
        let bottomColor = UIColor(red: 72.0/255.0, green: 114.0/255.0, blue: 184.0/255.0, alpha: 1.0).cgColor
        tintLayer.frame = view.bounds
        tintLayer.colors = [topColor, bottomColor]
    }
    
    // Background for night time
    func setNightTintBackground(){
        let topColor = UIColor(red: 151.0/255.0, green: 151.0/255.0, blue: 151.0/255.0, alpha: 1.0).cgColor
        let bottomColor = UIColor(red: 72.0/255.0, green: 72.0/255.0, blue: 72.0/255.0, alpha: 1.0).cgColor
        tintLayer.frame = view.bounds
        tintLayer.colors = [topColor, bottomColor]
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        backgroundView.layer.addSublayer(tintLayer) // Will display another layer, which is a gradient layer
        
        let indicatorSize: CGFloat = 70
        let indicatorFrame = CGRect(x: (view.frame.width-indicatorSize)/2, y: (view.frame.height-indicatorSize)/2, width: indicatorSize, height: indicatorSize) // Will have to calculate the size of the frame
        activityIndicator = NVActivityIndicatorView(frame: indicatorFrame, type: .lineScale, color: UIColor.white, padding: 20.0)
        activityIndicator.backgroundColor = UIColor.black
        view.addSubview(activityIndicator)
        
        locationManager.requestWhenInUseAuthorization() // Allow/Don't Allow popup location. Permission to access location.
        
        activityIndicator.startAnimating()  // Will call to display the loading animator
        if(CLLocationManager.locationServicesEnabled()){    // Will check if location service is avaliable
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            locationManager.startUpdatingLocation() // Will call to start updating the location
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        setDayTintBackground()
    }
    
    // Will manage the user's location and will change the image and background color
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let location = locations[0]
        lat = location.coordinate.latitude  // Latitude will be assigned
        lon = location.coordinate.longitude // Longitude will be assigned
        Alamofire.request("http://api.openweathermap.org/data/2.5/weather?lat=\(lat)&lon=\(lon)&appid=\(apiKey)&units=metric").responseJSON {
            response in
            self.activityIndicator.stopAnimating()  // Will call to stop the loading animator
            if let responseStr = response.result.value {
                let jsonResponse = JSON(responseStr)
                let jsonWeather = jsonResponse["weather"].array![0]
                let jsonTemp = jsonResponse["main"]
                let imageName = jsonWeather["icon"].stringValue
                
                self.locationLabel.text = jsonResponse["name"].stringValue // To access the name of the location
                self.conditionImageView.image = UIImage(named: imageName)
                self.conditionLabel.text = jsonWeather["main"].stringValue
                self.temperatureLabel.text = "\(Int(round(jsonTemp["temp"].doubleValue)))" // Will get the temperature and round the integer
                
                // Will change the background if its day time or night time
                let date = Date() // Will get the day of the week
                let dateFormatter = DateFormatter() // Will reformat the recieved date
                dateFormatter.dateFormat = "EEEE"
                self.dayLabel.text = dateFormatter.string(from: date)
                
                // Getting the day and night images
                let imageEndingName = imageName.suffix(1)
                if(imageEndingName == "n"){
                    self.setNightTintBackground()
                }else{
                    self.setDayTintBackground()
                }
            }
        }
        self.locationManager.stopUpdatingLocation() // After getting the location data, it will call to stop updating the location
    }
    
}
